package b4a.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class b4xmainpage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.b4xmainpage");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.b4xmainpage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example.fileprovider _provider = null;
public b4a.example.main _main = null;
public b4a.example.starter _starter = null;
public b4a.example.b4xpages _b4xpages = null;
public b4a.example.b4xcollections _b4xcollections = null;
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
 //BA.debugLineNum = 20;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 21;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 22;BA.debugLine="Root.LoadLayout(\"MainPage\")";
_root.LoadLayout("MainPage",ba);
 //BA.debugLineNum = 23;BA.debugLine="Provider.Initialize";
_provider._initialize /*String*/ (ba);
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public String  _button1_click() throws Exception{
anywheresoftware.b4a.objects.IntentWrapper _intent1 = null;
 //BA.debugLineNum = 29;BA.debugLine="Sub Button1_Click";
 //BA.debugLineNum = 31;BA.debugLine="Dim Intent1 As Intent";
_intent1 = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Intent1.Initialize(Intent1.ACTION_MAIN, \"\")";
_intent1.Initialize(_intent1.ACTION_MAIN,"");
 //BA.debugLineNum = 33;BA.debugLine="Intent1.SetComponent(\"com.google.android.youtube/";
_intent1.SetComponent("com.google.android.youtube/.HomeActivity");
 //BA.debugLineNum = 34;BA.debugLine="StartActivity(Intent1)";
__c.StartActivity(ba,(Object)(_intent1.getObject()));
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public String  _button10_click() throws Exception{
anywheresoftware.b4a.objects.IntentWrapper _in = null;
 //BA.debugLineNum = 214;BA.debugLine="Private Sub Button10_Click";
 //BA.debugLineNum = 216;BA.debugLine="Dim in As Intent";
_in = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 217;BA.debugLine="in.Initialize(in.ACTION_VIEW, \"https://maps.googl";
_in.Initialize(_in.ACTION_VIEW,"https://maps.google.com/maps?f=d&daddr=25.03,121.56");
 //BA.debugLineNum = 219;BA.debugLine="StartActivity(in)";
__c.StartActivity(ba,(Object)(_in.getObject()));
 //BA.debugLineNum = 220;BA.debugLine="End Sub";
return "";
}
public String  _button11_click() throws Exception{
 //BA.debugLineNum = 222;BA.debugLine="Private Sub Button11_Click";
 //BA.debugLineNum = 229;BA.debugLine="End Sub";
return "";
}
public String  _button12_click() throws Exception{
String _text = "";
anywheresoftware.b4a.objects.IntentWrapper _in = null;
 //BA.debugLineNum = 233;BA.debugLine="Private Sub Button12_Click";
 //BA.debugLineNum = 236;BA.debugLine="Dim text As String = \"B4X測試\"";
_text = "B4X測試";
 //BA.debugLineNum = 238;BA.debugLine="Dim in As Intent";
_in = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 239;BA.debugLine="in.Initialize(in.ACTION_VIEW, $\"line://msg/text/$";
_in.Initialize(_in.ACTION_VIEW,("line://msg/text/"+__c.SmartStringFormatter("",(Object)(_text))+""));
 //BA.debugLineNum = 242;BA.debugLine="StartActivity(in)";
__c.StartActivity(ba,(Object)(_in.getObject()));
 //BA.debugLineNum = 244;BA.debugLine="End Sub";
return "";
}
public String  _button2_click() throws Exception{
anywheresoftware.b4a.objects.IntentWrapper _intent1 = null;
 //BA.debugLineNum = 37;BA.debugLine="Private Sub Button2_Click";
 //BA.debugLineNum = 38;BA.debugLine="Try";
try { //BA.debugLineNum = 40;BA.debugLine="Dim intent1 As Intent";
_intent1 = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 43;BA.debugLine="intent1.Initialize(intent1.ACTION_SEND, \"eric197";
_intent1.Initialize(_intent1.ACTION_SEND,"eric19740521@gmail.com");
 //BA.debugLineNum = 47;BA.debugLine="intent1.putExtra(\"android.intent.extra.SUBJECT\",";
_intent1.PutExtra("android.intent.extra.SUBJECT",(Object)("B4X測試"));
 //BA.debugLineNum = 48;BA.debugLine="intent1.putExtra(\"android.intent.extra.TEXT\", \"B";
_intent1.PutExtra("android.intent.extra.TEXT",(Object)("B4X程式碼 測測測測測測"));
 //BA.debugLineNum = 49;BA.debugLine="intent1.setType(\"text/plain\")";
_intent1.SetType("text/plain");
 //BA.debugLineNum = 60;BA.debugLine="intent1.WrapAsIntentChooser(\"選擇寄信APP\")		'沒辦法.試了很";
_intent1.WrapAsIntentChooser("選擇寄信APP");
 //BA.debugLineNum = 72;BA.debugLine="StartActivity(intent1)";
__c.StartActivity(ba,(Object)(_intent1.getObject()));
 } 
       catch (Exception e10) {
			ba.setLastException(e10); //BA.debugLineNum = 74;BA.debugLine="ToastMessageShow(\"No mail apps\", True)";
__c.ToastMessageShow(BA.ObjectToCharSequence("No mail apps"),__c.True);
 };
 //BA.debugLineNum = 76;BA.debugLine="End Sub";
return "";
}
public String  _button3_click() throws Exception{
anywheresoftware.b4a.objects.IntentWrapper _in = null;
String _number = "";
 //BA.debugLineNum = 78;BA.debugLine="Private Sub Button3_Click";
 //BA.debugLineNum = 79;BA.debugLine="Dim In As Intent";
_in = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 80;BA.debugLine="Dim number = \"09123456789\" As String";
_number = "09123456789";
 //BA.debugLineNum = 81;BA.debugLine="In.Initialize(In.ACTION_VIEW, \"sms:\" & number)";
_in.Initialize(_in.ACTION_VIEW,"sms:"+_number);
 //BA.debugLineNum = 82;BA.debugLine="In.PutExtra(\"sms_body\", \"this is the body\")";
_in.PutExtra("sms_body",(Object)("this is the body"));
 //BA.debugLineNum = 83;BA.debugLine="StartActivity(In)";
__c.StartActivity(ba,(Object)(_in.getObject()));
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
return "";
}
public String  _button4_click() throws Exception{
String _filetosend = "";
anywheresoftware.b4a.objects.IntentWrapper _in = null;
 //BA.debugLineNum = 86;BA.debugLine="Private Sub Button4_Click";
 //BA.debugLineNum = 96;BA.debugLine="Try";
try { //BA.debugLineNum = 101;BA.debugLine="Log(Provider.SharedFolder)";
__c.LogImpl("5983055",_provider._sharedfolder /*String*/ ,0);
 //BA.debugLineNum = 102;BA.debugLine="Dim FileToSend As String = \"test.txt\"";
_filetosend = "test.txt";
 //BA.debugLineNum = 103;BA.debugLine="File.WriteString(Provider.SharedFolder, FileToSe";
__c.File.WriteString(_provider._sharedfolder /*String*/ ,_filetosend,"jaklsdjalksdjalskdjasld");
 //BA.debugLineNum = 106;BA.debugLine="Dim in As Intent";
_in = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 107;BA.debugLine="in.Initialize(in.ACTION_SEND, \"\")";
_in.Initialize(_in.ACTION_SEND,"");
 //BA.debugLineNum = 108;BA.debugLine="in.SetType(\"*/*\")";
_in.SetType("*/*");
 //BA.debugLineNum = 109;BA.debugLine="in.PutExtra(\"android.intent.extra.STREAM\", Provi";
_in.PutExtra("android.intent.extra.STREAM",_provider._getfileuri /*Object*/ (_filetosend));
 //BA.debugLineNum = 110;BA.debugLine="in.Flags = 1 'FLAG_GRANT_READ_URI_PERMISSION";
_in.setFlags((int) (1));
 //BA.debugLineNum = 112;BA.debugLine="in.WrapAsIntentChooser(\"Select\")";
_in.WrapAsIntentChooser("Select");
 //BA.debugLineNum = 113;BA.debugLine="StartActivity(in)";
__c.StartActivity(ba,(Object)(_in.getObject()));
 } 
       catch (Exception e13) {
			ba.setLastException(e13); //BA.debugLineNum = 115;BA.debugLine="Log(LastException)";
__c.LogImpl("5983069",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 118;BA.debugLine="End Sub";
return "";
}
public String  _button5_click() throws Exception{
String _subjectstr = "";
String _msgstr = "";
String _filetosend = "";
anywheresoftware.b4a.objects.IntentWrapper _int1 = null;
 //BA.debugLineNum = 120;BA.debugLine="Private Sub Button5_Click";
 //BA.debugLineNum = 121;BA.debugLine="Dim subjectstr As String = \"my subject\"";
_subjectstr = "my subject";
 //BA.debugLineNum = 122;BA.debugLine="Dim msgstr As String = \"my msg\"";
_msgstr = "my msg";
 //BA.debugLineNum = 124;BA.debugLine="Dim FileToSend As String = \"test.txt\"";
_filetosend = "test.txt";
 //BA.debugLineNum = 125;BA.debugLine="File.WriteString(Provider.SharedFolder, FileToSen";
__c.File.WriteString(_provider._sharedfolder /*String*/ ,_filetosend,"jaklsdjalksdjalskdjasld");
 //BA.debugLineNum = 131;BA.debugLine="Dim int1 As Intent";
_int1 = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 132;BA.debugLine="int1.Initialize(int1.ACTION_SEND, \"\")";
_int1.Initialize(_int1.ACTION_SEND,"");
 //BA.debugLineNum = 133;BA.debugLine="int1.PutExtra(\"android.intent.extra.SUBJECT\",subj";
_int1.PutExtra("android.intent.extra.SUBJECT",(Object)(_subjectstr));
 //BA.debugLineNum = 134;BA.debugLine="int1.putExtra(\"android.intent.extra.TEXT\",msgstr)";
_int1.PutExtra("android.intent.extra.TEXT",(Object)(_msgstr));
 //BA.debugLineNum = 135;BA.debugLine="int1.PutExtra(\"android.intent.extra.STREAM\", Prov";
_int1.PutExtra("android.intent.extra.STREAM",_provider._getfileuri /*Object*/ (_filetosend));
 //BA.debugLineNum = 136;BA.debugLine="int1.SetType(\"message/rfc822\")";
_int1.SetType("message/rfc822");
 //BA.debugLineNum = 137;BA.debugLine="int1.WrapAsIntentChooser(\"Select\") 'will show alw";
_int1.WrapAsIntentChooser("Select");
 //BA.debugLineNum = 138;BA.debugLine="StartActivity(int1)";
__c.StartActivity(ba,(Object)(_int1.getObject()));
 //BA.debugLineNum = 140;BA.debugLine="End Sub";
return "";
}
public String  _button6_click() throws Exception{
anywheresoftware.b4a.objects.IntentWrapper _intent1 = null;
 //BA.debugLineNum = 147;BA.debugLine="Private Sub Button6_Click";
 //BA.debugLineNum = 149;BA.debugLine="Try";
try { //BA.debugLineNum = 150;BA.debugLine="Dim intent1 As Intent";
_intent1 = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 151;BA.debugLine="intent1.Initialize(\"android.intent.action.CALL\",";
_intent1.Initialize("android.intent.action.CALL","tel:0912345678");
 //BA.debugLineNum = 152;BA.debugLine="StartActivity(intent1)";
__c.StartActivity(ba,(Object)(_intent1.getObject()));
 } 
       catch (Exception e6) {
			ba.setLastException(e6); //BA.debugLineNum = 154;BA.debugLine="Log(LastException)";
__c.LogImpl("51114119",BA.ObjectToString(__c.LastException(ba)),0);
 //BA.debugLineNum = 155;BA.debugLine="xui.MsgboxAsync(LastException, \"B4X\")";
_xui.MsgboxAsync(ba,BA.ObjectToCharSequence(__c.LastException(ba).getObject()),BA.ObjectToCharSequence("B4X"));
 };
 //BA.debugLineNum = 161;BA.debugLine="End Sub";
return "";
}
public String  _button7_click() throws Exception{
anywheresoftware.b4a.objects.IntentWrapper _in = null;
 //BA.debugLineNum = 163;BA.debugLine="Private Sub Button7_Click";
 //BA.debugLineNum = 165;BA.debugLine="Dim in As Intent";
_in = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 166;BA.debugLine="in.Initialize(in.ACTION_SEND, \"\")";
_in.Initialize(_in.ACTION_SEND,"");
 //BA.debugLineNum = 168;BA.debugLine="in.putExtra(\"android.intent.extra.TEXT\",\"我是誰\")";
_in.PutExtra("android.intent.extra.TEXT",(Object)("我是誰"));
 //BA.debugLineNum = 170;BA.debugLine="in.SetType(\"text/plain\")";
_in.SetType("text/plain");
 //BA.debugLineNum = 172;BA.debugLine="StartActivity(in)";
__c.StartActivity(ba,(Object)(_in.getObject()));
 //BA.debugLineNum = 174;BA.debugLine="End Sub";
return "";
}
public String  _button8_click() throws Exception{
anywheresoftware.b4a.objects.IntentWrapper _inten = null;
String _tmpt = "";
 //BA.debugLineNum = 176;BA.debugLine="Private Sub Button8_Click";
 //BA.debugLineNum = 178;BA.debugLine="File.Copy(File.DirAssets,\"a.gif\",Provider.SharedF";
__c.File.Copy(__c.File.getDirAssets(),"a.gif",_provider._sharedfolder /*String*/ ,"a.gif");
 //BA.debugLineNum = 180;BA.debugLine="If File.Exists(Provider.SharedFolder, \"a.gif\") =";
if (__c.File.Exists(_provider._sharedfolder /*String*/ ,"a.gif")==__c.False) { 
 //BA.debugLineNum = 181;BA.debugLine="xui.MsgboxAsync(\"檔案不存在\", \"B4X\")";
_xui.MsgboxAsync(ba,BA.ObjectToCharSequence("檔案不存在"),BA.ObjectToCharSequence("B4X"));
 //BA.debugLineNum = 183;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 189;BA.debugLine="Dim inten As Intent";
_inten = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 190;BA.debugLine="Dim tmpt As String = \"your text\"";
_tmpt = "your text";
 //BA.debugLineNum = 191;BA.debugLine="inten.Initialize(inten.ACTION_SEND,\"\")";
_inten.Initialize(_inten.ACTION_SEND,"");
 //BA.debugLineNum = 192;BA.debugLine="inten.SetType(\"image/*\")";
_inten.SetType("image/*");
 //BA.debugLineNum = 193;BA.debugLine="inten.PutExtra(\"android.intent.extra.STREAM\",Prov";
_inten.PutExtra("android.intent.extra.STREAM",_provider._getfileuri /*Object*/ ("a.gif"));
 //BA.debugLineNum = 194;BA.debugLine="inten.PutExtra(\"android.intent.extra.TEXT\",tmpt)";
_inten.PutExtra("android.intent.extra.TEXT",(Object)(_tmpt));
 //BA.debugLineNum = 197;BA.debugLine="inten.WrapAsIntentChooser(\"選擇APP\") 'will show alw";
_inten.WrapAsIntentChooser("選擇APP");
 //BA.debugLineNum = 198;BA.debugLine="StartActivity(inten)";
__c.StartActivity(ba,(Object)(_inten.getObject()));
 //BA.debugLineNum = 199;BA.debugLine="End Sub";
return "";
}
public String  _button9_click() throws Exception{
anywheresoftware.b4a.objects.IntentWrapper _in = null;
 //BA.debugLineNum = 201;BA.debugLine="Private Sub Button9_Click";
 //BA.debugLineNum = 206;BA.debugLine="Dim in As Intent";
_in = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 207;BA.debugLine="in.Initialize(in.ACTION_VIEW, \"https://google.com";
_in.Initialize(_in.ACTION_VIEW,"https://google.com/search?q=b4x");
 //BA.debugLineNum = 209;BA.debugLine="StartActivity(in)";
__c.StartActivity(ba,(Object)(_in.getObject()));
 //BA.debugLineNum = 212;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private Root As B4XView";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Public Provider As FileProvider";
_provider = new b4a.example.fileprovider();
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 15;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
